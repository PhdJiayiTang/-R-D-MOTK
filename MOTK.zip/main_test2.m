clc
clear
Data={'yaleA_3view','Handwritten_numerals','cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','stl10_fea_Per1','SUNRGBD_fea_Per1'};
Name={'yaleA_3view','Handwritten_numerals','cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','stl10_fea_Per1','SUNRGBD_fea_Per1'};
iii = 2;
load([Data{iii},'.mat']);
% if strcmp(Data{iii},'yaleA_3view') || strcmp(Data{iii},'Handwritten_numerals') || strcmp(Data{iii},'ORL_mtv')  || strcmp(Data{iii},'Wiki_fea') || strcmp(Data{iii},'WebKB_2views') 
%     load(strcat('D:\BBC\multi-view-dataset\',Data{iii},'.mat'));
% elseif strcmp(Data{iii},'CiteSeer')
%     load('D:\BBC\Multi-view_Graph_Learning-master\data\CiteSeer.mat');
%     X=fea;
%     Y=gt;
% else
%     load(strcat('D:\Incomplete multi-view datasets\',Data{iii},'.mat'));
%     X=data;
%     Y=truelabel{1,1};
% end
type='euclidean';
% type='cosine';
clear data truelabel MissingStatus index

knn=5; %'stl10_fea_Per1',knn=5 or 3, type='euclidean'; yaleA_3view, 'cosine' or 'euclidean', knn=5; Reuters, euclidean, k=15; Handwritten_numerals, type='euclidean', MVC_EKD-k=5, MVC_EKR-5=10
num_view = length(X);  
num_sample = length(Y);
numClust = length(unique(Y));
affinity = cell(num_view,1);
Result=cell(num_view,1);
time_km=0;
time_Ekm=0;
for i=1:num_view
    try
        % if strcmp(Data{iii},'Reuters_Per1')
            load([Data{iii},'_kernel',num2str(i),'.mat']);
        % else
            % load([Data{iii},'_kernel',num2str(i),'.mat']);
        % end
    catch
        if size(X{i},1)==num_sample 
            W = make_affinity_matrix(X{i}, type);
        else
            W = make_affinity_matrix(X{i}', type);
        end
        save([Data{iii},'_kernel',num2str(i),'.mat'],'W');
%         original_affinity{i} = W;
    end
    if knn ~= 0  % not using fully connected graph
        [W, ~] = kNN(W, knn);
        [ W] = SpectralClustering(W, numClust, 3);
    end
    affinity{i,1} = W;
end

time_km = time_km / (10*num_view);
time_Ekm = time_Ekm / (10*num_view);
clear W original_affinity idx X
clc
epsilon = 1e-4;
T_D = 0;
T_R = 0;
% T3_v2 = 0;
% Mu = spdiags(1/num_sample*ones(num_sample,1), 0, num_sample, num_sample);
Mu = 1 / num_sample;
for t=1:10

tic
[label2_v2, ~, ~, Totsum_D] = DMOTK(affinity, Mu, numClust, epsilon);%,'Distance','cosine'
T_D=T_D+toc;
result_D(t,:)= ClusteringMeasure(Y,label2_v2);% [ACC nmi Purity]
Totsum2_D{t}=Totsum_D;

tic
[label3_v2, ~, ~,Totsum_R] = RMOTK(affinity, Mu, numClust, epsilon);
T_R=T_R+toc;
result_R(t,:)= ClusteringMeasure(Y,label3_v2);% [ACC nmi Purity]
Totsum2_R{t}=Totsum_R;

end
T_D = T_D/10
T_R = T_R/10
[mean(result_D), std(result_D);  min(result_D), max(result_D)]
[mean(result_R), std(result_R);  min(result_R), max(result_R)]
