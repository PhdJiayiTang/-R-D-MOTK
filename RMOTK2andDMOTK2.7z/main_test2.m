clc
clear
addpath('C:\MATLAB tool\MATLAB-tools-master')
Data={'yaleA_3view','Handwritten_numerals','cifar10_Per1','cifar100_Per1','fmnist_Per1','MNIST_fea_Per1','stl10_fea_Per1','SUNRGBD_fea_Per1'};
Name={'Yale','Handwritten','CIFAR10','CIFAR100','FMNIST','MNIST','STL-10','SUNRGBD'};
iii = 7;
% for iii =1:length(Data)
if strcmp(Data{iii},'yaleA_3view') || strcmp(Data{iii},'Handwritten_numerals') || strcmp(Data{iii},'ORL_mtv')  || strcmp(Data{iii},'Wiki_fea') || strcmp(Data{iii},'WebKB_2views') 
    load(strcat('D:\BBC\multi-view-dataset\',Data{iii},'.mat'));
    for  v=1:length(X)
        X{v}=X{v}';
    end
elseif strcmp(Data{iii},'CiteSeer')
    load('D:\BBC\Multi-view_Graph_Learning-master\data\CiteSeer.mat');
    X=fea;
    Y=gt;
else
    load(strcat('D:\Incomplete multi-view datasets\',Data{iii},'.mat'));
    X=data;
    Y=truelabel{1,1};
end
type='euclidean';
% type='cosine';
clear data truelabel MissingStatus index

knn=5; %'stl10_fea_Per1',knn=5 or 3, type='euclidean'; yaleA_3view, 'cosine' or 'euclidean', knn=5; Reuters, euclidean, k=15; Handwritten_numerals, type='euclidean', MVC_EKD-k=5, MVC_EKR-5=10
num_view = length(X);  
num_sample = length(Y);
numClust = length(unique(Y));
%%{'rbf','poly','t','laplace','sigmoid'}和{'rbf','poly','t','laplace'}情况下，RMOTK在Handwritten数据集上表现不佳。
% allKernels = {'poly'};
% allKernels = {};
allKernels = {'rbf','poly','t'};
num_kernel = length(allKernels);
affinity = cell(num_view,num_kernel);
affinity2 = cell(num_view,1);
Result=cell(num_view,num_kernel);
Result2=cell(num_view,num_kernel);
Result_obj=cell(num_view,num_kernel);
Result2_obj=cell(num_view,num_kernel);
Result_raw=cell(num_view,num_kernel);
Result2_raw=cell(num_view,num_kernel);
Result_obj_raw=cell(num_view,num_kernel);
Result2_obj_raw=cell(num_view,num_kernel);
time_km=0;
time_Ekm=0;
for i=1:num_view
    KernelMatrix = knnKernelMatrix(X{i}', knn, 'enable_kernels', allKernels);
    result = zeros(10,3);
    result2 = zeros(10,3);
    obj = zeros(10,1);
    obj2 = zeros(10,1);
    result_raw = zeros(10,3);
    result2_raw = zeros(10,3);
    obj_raw = zeros(10,1);
    obj2_raw = zeros(10,1);
    if knn ~= 0  % not using fully connected graph
        for h = 1:num_kernel
            name = allKernels{h};
            [W, ~] = kNN(KernelMatrix.(name).affinity, knn);
        [ W] = SpectralClustering(W, numClust, 3);
        for t=1:10
            tic
            [label, ~, ~, SUMD]=litekmeans(W, numClust);
            time_km=time_km+toc;
            result(t,:)= ClusteringMeasure(Y, label);
            obj(t) = sum(SUMD);
            [label, ~, ~, SUMD]=litekmeans(X{i}', numClust);
            result_raw(t,:)= ClusteringMeasure(Y, label);
            obj_raw(t) = sum(SUMD);
            tic
            [label2, ~, D]=Entropical_kmeans(W, numClust);
            time_Ekm=time_Ekm+toc;
            result2(t,:)= ClusteringMeasure(Y, label2);
            obj2(t) = D(end);
            [label2, ~, D]=Entropical_kmeans(X{i}', numClust);
            result2_raw(t,:)= ClusteringMeasure(Y, label2);
            obj2_raw(t) = D(end);
        end
    Result{i,h} = result;
    Result2{i,h} = result2;
    Result_obj{i,h} = obj;
    Result2_obj{i,h} = obj2;
    Result_raw{i,h} = result_raw;
    Result2_raw{i,h} = result2_raw;
    Result_obj_raw{i,h} = obj_raw;
    Result2_obj_raw{i,h} = obj2_raw;
    affinity{i,h} = W;
        end
    end
    affinity2{i,1} = X{i}';
end

time_km = time_km / (10*num_view*num_kernel);
time_Ekm = time_Ekm / (10*num_view*num_kernel);
clear W original_affinity idx X
if strcmp(Data{iii},'fmnist_Per1')
    for i=1:2
        for h = 1:length(allKernels)
            affinity{i,h} = affinity2{i,1};
        end
    end
elseif strcmp(Data{iii},'SUNRGBD_fea_Per1')
    for i=2
        for h = 1:length(allKernels)
            affinity{i,h} = affinity2{i,1};
        end
    end
end
Affinity = affinity(:);
clc
epsilon = 1e-6;
T_D = 0;
T_R = 0;
Mu = 1 / num_sample;
for t=1:10

tic
[label2_v2] = DMOTK2(Affinity, Mu, numClust, epsilon);%,'Distance','cosine'
T_D=T_D+toc;
result_D(t,:)= ClusteringMeasure(Y,label2_v2);% [ACC nmi Purity]


tic
[label3_v2] = RMOTK2(Affinity, Mu, numClust, epsilon);
T_R=T_R+toc;
result_R(t,:)= ClusteringMeasure(Y,label3_v2);% [ACC nmi Purity]


end
T_D = T_D/10
T_R = T_R/10
[mean(result_D), std(result_D);  min(result_D), max(result_D)]
[mean(result_R), std(result_R);  min(result_R), max(result_R)]
