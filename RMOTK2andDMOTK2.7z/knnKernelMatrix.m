function results = knnKernelMatrix(X, k, varargin)
% 计算每个样本的最近k个邻居的多种核函数值（智能近邻策略 + 自动调参 + 稀疏支持）
%
% 输出：结构体 results，每个启用的核字段含：
%   .values  - n×k 核值矩阵
%   .indices - n×k 近邻索引（按核类型分组）
%
% 输入参数：
%   X - n×d 样本矩阵（支持 full / sparse）
%   k - 近邻数 (0 < k < n)
%   可选参数：
%     'gamma_*', 'r_*', 'd_*', 'nu_*', 'eps_*'
%     'enable_kernels' - 默认 {'rbf','poly','t'}
%     'auto_tune' - 'on'/'off'（默认 'off'）
%     'tune_method' - 'median'/'silverman'（默认 'median'）
%     'normalize_kernel' - 'none'/'cosine'/'diagonal'（默认 'none'）
%     'verbose' - 是否显示调参信息（默认 false）

    % === 参数解析 ===
    [n, d] = size(X);
    isSparse = issparse(X);
    p = inputParser;
    addRequired(p, 'X', @ismatrix);
    addRequired(p, 'k', @(x) x>0 && x < n && round(x)==x);
    
    % 核参数
    addParameter(p, 'gamma_rbf', NaN, @isnumeric);
    addParameter(p, 'gamma_poly', 1, @isnumeric);
    addParameter(p, 'r_poly', 1, @isnumeric);
    addParameter(p, 'd_poly', 2, @(x) x>0 && round(x)==x);
    addParameter(p, 'gamma_t', NaN, @isnumeric);
    addParameter(p, 'nu_t', 1, @(x) x>0);
    addParameter(p, 'gamma_laplace', NaN, @isnumeric);
    addParameter(p, 'gamma_chi2', 1, @isnumeric);
    addParameter(p, 'eps_chi2', 1e-8, @(x) x>=0);
    addParameter(p, 'gamma_js', 1, @isnumeric);
    addParameter(p, 'gamma_anova', NaN, @isnumeric);
    addParameter(p, 'd_anova', 2, @(x) x>0 && round(x)==x);
    
    % 控制参数
    allKernels = {'linear','rbf','poly','t','laplace','sigmoid','chi2','intersection','hellinger','js','anova'};
    addParameter(p, 'enable_kernels', ["rbf","poly","t"], ...
    @(x) validateKernelList(x, allKernels));
    addParameter(p, 'auto_tune', 'off', @(x) ismember(x, {'on','off'}));
    addParameter(p, 'tune_method', 'median', @(x) ismember(x, {'median','silverman'}));
    addParameter(p, 'normalize_kernel', 'none', @(x) ismember(x, {'none','cosine','diagonal'}));
    addParameter(p, 'verbose', false, @islogical);
    
    parse(p, X, k, varargin{:});
    params = p.Results;
    enableKernels = params.enable_kernels;
    doAutoTune = strcmpi(params.auto_tune, 'on');
    normMethod = params.normalize_kernel;
    verbose = params.verbose;

    % === 检测是否 L2 归一化（关键！）===
    norms = vecnorm(X, 2, 2);
    isL2Normalized = (std(norms) < 1e-6) && (mean(norms) > 0.99); % 容忍浮点误差

    if verbose
        if isL2Normalized
            fprintf('Detected L2-normalized data. Using unified Euclidean neighbors.\n');
        else
            fprintf('Data not L2-normalized. Using kernel-specific neighbor strategies.\n');
        end
    end

    % === 自动调参（仅对 gamma_* 且值为 NaN 的参数）===
    if doAutoTune
        if strcmpi(params.tune_method, 'median')
            if n > 1000
                idx_sample = randperm(n, min(1000, n));
                X_sample = X(idx_sample, :);
                D_sq = pdist2(X_sample, X_sample, 'squaredeuclidean');
                D_sq = D_sq(D_sq > 0);
                gamma_default = 1 / max(median(D_sq), 1e-10);
            else
                D_sq = pdist2(X, X, 'squaredeuclidean');
                D_sq = D_sq(D_sq > 0);
                gamma_default = 1 / max(median(D_sq), 1e-10);
            end
        else % 'silverman'
            sigma_sq = mean(var(X, 0, 1));
            if sigma_sq == 0, sigma_sq = 1; end
            silverman_h = sigma_sq * (4/(d+2)/n)^(2/(d+4));
            gamma_default = 1 / max(silverman_h, 1e-10);
        end
        
        for fn = fieldnames(params)'
            name = fn{1};
            if startsWith(name, 'gamma_') && isnan(params.(name))
                params.(name) = gamma_default;
                if verbose
                    fprintf('Auto-tuned %s = %.4g\n', name, gamma_default);
                end
            end
        end
    else
        for fn = fieldnames(params)'
            name = fn{1};
            if startsWith(name, 'gamma_') && isnan(params.(name))
                params.(name) = 1/d;
            end
        end
    end

    % === 分组计算近邻 ===
    % 内积类核：linear, poly, sigmoid
    innerKernels = {'linear', 'poly', 'sigmoid'};
    useInner = any(ismember(enableKernels, innerKernels));
    
    % 距离类核：rbf, t, laplace, chi2, intersection, hellinger, js, anova
    distKernels = {'rbf','t','laplace','chi2','intersection','hellinger','js','anova'};
    useDist = any(ismember(enableKernels, distKernels));

    % 存储不同近邻索引
    Idx_inner = []; Idx_dist = [];

    if isL2Normalized
        % 统一使用欧氏近邻（高效 + 语义一致）
        if isSparse
            [Idx_dist, Dist] = knnsearch(X, X, 'K', k, 'Distance', 'seuclidean', 'NSMethod', 'kdtree');
        else
            [Idx_dist, Dist] = knnsearch(X, X, 'K', k, 'Distance', 'seuclidean');
        end
        Idx_inner = Idx_dist; % 共享
        DistSq = Dist.^2;
    else
        % 分别计算
        if useInner
            temp_X = normalize(X,2,'norm');
            temp_X(isnan(temp_X)) = 0;
            [Idx_inner, ~] = knnsearch(temp_X, temp_X, 'K', k, 'Distance', 'cosine'); % 自动 exhaustive
            clear temp_X
            % [Idx_inner, ~] = knnsearch(X, X, 'K', k, 'Distance', 'cosine'); % 自动 exhaustive
        end
        if useDist
            if isSparse
                [Idx_dist, Dist] = knnsearch(X, X, 'K', k, 'Distance', 'seuclidean', 'NSMethod', 'kdtree');
            else
                [Idx_dist, Dist] = knnsearch(X, X, 'K', k, 'Distance', 'seuclidean');
            end
            DistSq = Dist.^2;
        end
    end

    % === 初始化结果结构体 ===
    results = struct();

    % === 辅助函数：计算内积和 L1 距离（向量化无循环）===
    computeInnerAndL1 = @(Idx) deal( ...
        reshape(sum(repelem(X, k, 1) .* X(Idx(:), :), 2), n, k), ... % inner_prod
        reshape(sum(abs(repelem(X, k, 1) - X(Idx(:), :)), 2), n, k) ... % DistL1
    );

    % === 核函数计算 ===

    % --- 内积类核 ---
    if useInner
        [inner_prod, ~] = computeInnerAndL1(Idx_inner);
        col_idx = Idx_inner(:); 
        [I, ~] = ndgrid(1:n, 1:k);
        row_idx = I(:);
        if ismember('linear', enableKernels)
            vals = inner_prod(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A'); % 对称化
            results.linear.affinity = A;
            % results.linear.threshold = (prctile(results.linear.values, 80, 1) + mean(results.linear.values, 1) + 0.84 * std(results.linear.values, [], 1)) / 2;
        end
        if ismember('poly', enableKernels)
            K = (params.gamma_poly * inner_prod + params.r_poly) .^ params.d_poly;
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A'); % 对称化
            results.poly.affinity = A;
            % results.poly.threshold = (prctile(results.poly.values, 80, 1) + mean(results.poly.values, 1) + 0.84 * std(results.poly.values, [], 1)) / 2;
        end
        if ismember('sigmoid', enableKernels)
            K = tanh(params.gamma_poly * inner_prod + params.r_poly);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A'); % 对称化
            results.sigmoid.affinity = A;
            % results.sigmoid.threshold = (prctile(results.sigmoid.values, 80, 1) + mean(results.sigmoid.values, 1) + 0.84 * std(results.sigmoid.values, [], 1)) / 2;
        end
    end
    clear idx

    % --- 距离类核 ---
    if useDist
        [~, DistL1] = computeInnerAndL1(Idx_dist); % 仅需 DistL1
        col_idx = Idx_dist(:);
        [I, ~] = ndgrid(1:n, 1:k);
        row_idx = I(:);
        if ismember('rbf', enableKernels)
            K = exp(-params.gamma_rbf * DistSq);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.rbf.affinity = A; % 关键：输出完整的亲和矩阵
            % results.rbf.threshold = (prctile(results.rbf.values, 80, 1) + mean(results.rbf.values, 1) + 0.84 * std(results.rbf.values, [], 1)) / 2;
        end
        if ismember('t', enableKernels)
            K = 1 ./ (1 + params.gamma_t * DistSq) .^ params.nu_t;
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.t.affinity = A; % 关键：输出完整的亲和矩阵
            % results.t.threshold = (prctile(results.t.values, 80, 1) + mean(results.t.values, 1) + 0.84 * std(results.t.values, [], 1)) / 2;
        end
        if ismember('laplace', enableKernels)
            K = exp(-params.gamma_laplace * DistL1);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.laplace.affinity = A; % 关键：输出完整的亲和矩阵
            % results.laplace.threshold = (prctile(results.laplace.values, 80, 1) + mean(results.laplace.values, 1) + 0.84 * std(results.laplace.values, [], 1)) / 2;
        end
        
        % 直方图核（需非负处理）
        X_nonneg = max(X, 0);
        neighborIdx_dist = Idx_dist(:);
        if ismember('chi2', enableKernels)
            Xq = repelem(full(X_nonneg), k, 1);
            Xn = full(X_nonneg(neighborIdx_dist, :));
            diff_sq = (Xq - Xn).^2;
            sum_xn = Xq + Xn + params.eps_chi2;
            chi2_mat = reshape(sum(diff_sq ./ sum_xn, 2), n, k);
            K = exp(-params.gamma_chi2 * chi2_mat);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.chi2.affinity = A; % 关键：输出完整的亲和矩阵
            % results.chi2.threshold = (prctile(results.chi2.values, 80, 1) + mean(results.chi2.values, 1) + 0.84 * std(results.chi2.values, [], 1)) / 2;
        end
        if ismember('intersection', enableKernels)
            Xq = repelem(full(X_nonneg), k, 1);
            Xn = full(X_nonneg(neighborIdx_dist, :));
            K = reshape(sum(min(Xq, Xn), 2), n, k);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.intersection.affinity = A; % 关键：输出完整的亲和矩阵
            % results.intersection.threshold = (prctile(results.intersection.values, 80, 1) + mean(results.intersection.values, 1) + 0.84 * std(results.intersection.values, [], 1)) / 2;
        end
        if ismember('hellinger', enableKernels)
            row_sum = sum(X, 2);
            X_norm = X ./ max(row_sum, 1e-10);
            X_norm = max(X_norm, 0);
            Xq = repelem(sqrt(full(X_norm)), k, 1);
            Xn = sqrt(full(X_norm(neighborIdx_dist, :)));
            K = reshape(sum(Xq .* Xn, 2), n, k);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.hellinger.affinity = A; % 关键：输出完整的亲和矩阵
            % results.hellinger.threshold = (prctile(results.hellinger.values, 80, 1) + mean(results.hellinger.values, 1) + 0.84 * std(results.hellinger.values, [], 1)) / 2;
        end
        if ismember('js', enableKernels)
            row_sum = sum(X, 2);
            X_prob = X ./ max(row_sum, 1e-10);
            Xq = repelem(full(X_prob), k, 1);
            Xn = full(X_prob(neighborIdx_dist, :));
            m = 0.5 * (Xq + Xn);
            kl_xm = sum(Xq .* log((Xq + 1e-10) ./ (m + 1e-10)), 2);
            kl_ym = sum(Xn .* log((Xn + 1e-10) ./ (m + 1e-10)), 2);
            js_mat = reshape(0.5 * (kl_xm + kl_ym), n, k);
            K = exp(-params.gamma_js * js_mat);
            vals = K(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.js.affinity = A; % 关键：输出完整的亲和矩阵
            % results.js.threshold = (prctile(results.js.values, 80, 1) + mean(results.js.values, 1) + 0.84 * std(results.js.values, [], 1)) / 2;
        end
        if ismember('anova', enableKernels) && params.d_anova == 2
            anova_val = zeros(n, k);
            Xq = repelem(X, k, 1);
            Xn = X(neighborIdx_dist, :);
            for i = 1:d-1
                for j = i+1:d
                    term = exp(-params.gamma_anova * (Xq(:,i)-Xn(:,i)).^2) .* ...
                           exp(-params.gamma_anova * (Xq(:,j)-Xn(:,j)).^2);
                    anova_val = anova_val + reshape(term, n, k);
                end
            end
            vals = anova_val(:);
            A = sparse(row_idx, col_idx, vals, n, n);
            A = max(A, A');% 强制对称（取最大值，保持稀疏结构）
            results.anova.affinity = A; % 关键：输出完整的亲和矩阵
            % results.anova.threshold = (prctile(results.anova.values, 80, 1) + mean(results.anova.values, 1) + 0.84 * std(results.anova.values, [], 1)) / 2;
        elseif ismember('anova', enableKernels)
            warning('ANOVA kernel only supports d_anova=2. Skipped.');
        end
    end
end

%% ========== 辅助函数：核矩阵归一化 ==========
function K_norm = normalizeKernelMatrix(K, method, neighborIdx)
if strcmpi(method, 'none')
    K_norm = K;
    return;
end

n = size(K, 1); k = size(K, 2);

if strcmpi(method, 'cosine')
    diagK = ones(n, 1);
    diagK_neighbors = diagK(neighborIdx);
    diagK_self = repelem(diagK, k, 1);
    norm_factor = sqrt(diagK_self .* diagK_neighbors);
    norm_factor = reshape(norm_factor, n, k);
    K_norm = K ./ max(norm_factor, 1e-10);
elseif strcmpi(method, 'diagonal')
    row_norm = sqrt(sum(K.^2, 2));
    row_norm = max(row_norm, 1e-10);
    K_norm = bsxfun(@rdivide, K, row_norm);
else
    K_norm = K;
end
end

function tf = validateKernelList(x, validKernels)
    if iscellstr(x)
        x_str = string(x);
    elseif isstring(x) && isvector(x)
        x_str = x(:)';
    else
        tf = false;
        return;
    end
    tf = all(ismember(x_str, validKernels));
end